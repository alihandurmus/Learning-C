/* lab1a.c 
 * NS
 * Printf Fonksiyonu
 */


#include <stdio.h>

int main()
{
	printf("Merhaba C dunyasi !\nMedeniyet cok guzel bir ortam.\nCilgin bir muhendis olacagim!!!");
	
	
	return 0;
}


