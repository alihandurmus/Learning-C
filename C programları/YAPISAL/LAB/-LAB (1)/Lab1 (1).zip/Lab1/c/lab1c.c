/* lab1c*/
#include <stdio.h>

int main()
{

   printf("\tLabCLabCLabC\n");
   printf("I can write a code without bugs\n");
   printf("\t I like this lab\t\n");
   printf("\t I like coding\t");

   return 0;
}
